let numero = 10; 

function decresentes(N) {
    for (let i = N; i >= 1; i--) {
        console.log(i);
    }
}


decresentes(numero);

