let numero = 10; 

function crescentes(N) {
    for (let i = 1; i <= N; i++) {
        console.log(i);
    }
}

crescentes(numero);


