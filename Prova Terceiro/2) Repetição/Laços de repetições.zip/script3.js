let numero = 10;

function pares(N) {
    for (let i = 1; i <= N; i++) {
        if(i % 2==0){
            console.log(i);

        }
       
    }
}

pares(numero);
